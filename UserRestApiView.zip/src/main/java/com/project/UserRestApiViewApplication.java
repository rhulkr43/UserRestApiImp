package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRestApiViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserRestApiViewApplication.class, args);
	}

}
